class Config :
    JWT_SECRET_KEY = 'yhacademy1029##heelo'
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True

    # AWS ifif3526
    ACCESS_KEY = 'AKIAUG5BIV4JCFV26JP2'
    SECRET_ACCESS = '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'

    # 버킷 이름과 이미지 주소 세팅
    S3_BUCKET = 'ifif3526-image-test'
    S3_LOCATION = 'https://ifif3526-image-test.s3.ap-northeast-2.amazonaws.com/'
